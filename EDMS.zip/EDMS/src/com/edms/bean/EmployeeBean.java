package com.edms.bean;

import java.util.Date;


public class EmployeeBean {
	private String empId;
	private String empFirstName;
	private String empLastName;
	private long empContactNumber;
	private Date empDoj;
	private String empEmail;
	public synchronized String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public long getEmpContactNumber() {
		return empContactNumber;
	}
	public void setEmpContactNumber(long empContactNumber) {
		this.empContactNumber = empContactNumber;
	}
	public Date getEmpDoj() {
		return empDoj;
	}
	public void setEmpDoj(Date empDoj) {
		this.empDoj = empDoj;
	}
	public String getEmpEmail() {
		return empEmail;
	}
	public void setEmpEmail(String empEmail) {
		this.empEmail = empEmail;
	}
	@Override
	public String toString() {
		return "Employee Id=" + empId + "\nempFirstName="
				+ empFirstName + "\nempLastName=" + empLastName
				+ "\nempContactNumber=" + empContactNumber + "\nempDoj="
				+ empDoj + "\nempEmail=" + empEmail + "";
	}
	
	
	
}
