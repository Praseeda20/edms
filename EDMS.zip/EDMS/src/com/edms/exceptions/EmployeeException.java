package com.edms.exceptions;

public class EmployeeException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1000L;

	public EmployeeException(String message) {
		super(message);
	}
	
}
