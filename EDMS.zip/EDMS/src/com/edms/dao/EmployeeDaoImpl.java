package com.edms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.edms.bean.EmployeeBean;
import com.edms.exceptions.EmployeeException;
import com.edms.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {

	private int generateEmployeeId() {
		int id = 0;
		Connection con = null;
		String qry = "Select emp_id_sequence.nextval from dual";
		try {
			con = DBConnection.getConnection();
			Statement stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (SQLException | EmployeeException e) {
			e.printStackTrace();
		}
		return id;
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {
		Connection con = null;
		int id = 0;
		String cmd = "Insert into employee_tbl (emp_id, emp_firstname, emp_lastname,"
				+ " emp_contactnumber, emp_doj, emp_email) "
				+ "values(?,?,?,?,sysdate,?)";
		try {
			con = DBConnection.getConnection();
			id = generateEmployeeId();
			PreparedStatement pstmt = con.prepareStatement(cmd);

			pstmt.setString(1, String.valueOf(id));
			pstmt.setString(2, bean.getEmpFirstName());
			pstmt.setString(3, bean.getEmpLastName());
			pstmt.setLong(4, bean.getEmpContactNumber());
			pstmt.setString(5, bean.getEmpEmail());

			pstmt.executeUpdate();

			System.out.println("Employee added successfully ID: " + id);
		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");
		}
		return id;
	}

	@Override
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException {
		EmployeeBean emp = new EmployeeBean();
		try {
			Connection con = null;
			String cmd = "select emp_id, emp_firstname, emp_lastname,"
					+ "emp_contactnumber, emp_doj, emp_email"
					+ " from employee_tbl where emp_id=(?)";
			con = DBConnection.getConnection();
			PreparedStatement prepstmt = con.prepareStatement(cmd);
			prepstmt.setInt(1, id);
			ResultSet rst = prepstmt.executeQuery();
			while (rst.next()) {
				emp.setEmpId((rst.getString(1).toString()));
				emp.setEmpFirstName(rst.getString(2));
				emp.setEmpLastName(rst.getString(3));
				emp.setEmpContactNumber(rst.getLong(4));
				emp.setEmpDoj(rst.getDate(5));
				emp.setEmpEmail(rst.getString(6));
				//System.out.println(emp);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return emp;
	}

}
