package com.edms.dao;

import com.edms.bean.EmployeeBean;
import com.edms.exceptions.EmployeeException;

public interface EmployeeDao {
	public int addEmployee(EmployeeBean bean) throws EmployeeException;
	public EmployeeBean viewEmployeeById(int id) throws EmployeeException;	
}
